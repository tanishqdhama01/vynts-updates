# Third-party notices

## OpenAI OAuth

Vynts supports a bundled build of:

- OpenAI OAuth `2.0.0`
- reviewed commit `4be9c04ccfcaa8fc0982044d17a29a82cb131374`
- <https://github.com/EvanZhouDev/openai-oauth>

Copyright 2026 Evan Zhou and OpenAI OAuth contributors.

OpenAI OAuth is licensed under the Apache License, Version 2.0. Distribution
artifacts must include the upstream `LICENSE` and `NOTICE` files plus notices for
the bundled Node.js runtime and transitive packages.

OpenAI OAuth is unofficial and is not affiliated with, endorsed by, or sponsored
by OpenAI. ChatGPT credentials must be treated like passwords. Use is subject to
OpenAI terms, usage policies, account limits, and any agreement applying to the
user's account.
